package edu.handong.csee.plt.ast.dfs;

public class MtSub implements Dfs {

	@Override
	public String getASTCode() {
		return "(mtSub)";
	}

}
