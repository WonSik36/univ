package edu.handong.csee.plt.exception;

public class UndefinedASTException extends BadSyntaxException{

	public UndefinedASTException(String err) {
		super(err);
	}
	
}
