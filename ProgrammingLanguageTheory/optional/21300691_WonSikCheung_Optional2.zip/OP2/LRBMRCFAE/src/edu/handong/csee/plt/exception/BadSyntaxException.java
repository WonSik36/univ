package edu.handong.csee.plt.exception;

public class BadSyntaxException extends RuntimeException {

	public BadSyntaxException(String err) {
		super(err);
	}

}
