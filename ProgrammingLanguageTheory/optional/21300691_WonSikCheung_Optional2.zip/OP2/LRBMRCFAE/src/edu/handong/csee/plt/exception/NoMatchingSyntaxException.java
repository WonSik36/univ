package edu.handong.csee.plt.exception;

public class NoMatchingSyntaxException extends BadSyntaxException{

	public NoMatchingSyntaxException(String err) {
		super(err);
	}

}
