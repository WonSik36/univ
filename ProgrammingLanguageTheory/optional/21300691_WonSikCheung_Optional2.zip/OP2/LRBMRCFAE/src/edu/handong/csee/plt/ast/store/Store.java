package edu.handong.csee.plt.ast.store;

import edu.handong.csee.plt.ast.AST;

public interface Store extends AST {

}
