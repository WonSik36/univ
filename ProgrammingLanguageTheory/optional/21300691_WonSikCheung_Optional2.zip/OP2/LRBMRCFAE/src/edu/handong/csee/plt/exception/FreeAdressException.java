package edu.handong.csee.plt.exception;

public class FreeAdressException extends BadSyntaxException{
	public FreeAdressException(String err) {
		super(err);
	}
}
