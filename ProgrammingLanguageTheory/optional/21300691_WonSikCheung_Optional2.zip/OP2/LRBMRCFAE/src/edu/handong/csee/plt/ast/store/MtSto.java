package edu.handong.csee.plt.ast.store;

public class MtSto implements Store {

	@Override
	public String getASTCode() {
		return "(mtSto)";
	}
}