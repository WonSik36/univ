package edu.handong.csee.plt.ast.vs;

import edu.handong.csee.plt.ast.AST;

public interface ValueStore extends AST {

}
