package edu.handong.csee.plt.ast.dfs;

import edu.handong.csee.plt.ast.AST;

public interface Dfs extends AST {

}
