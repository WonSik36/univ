package edu.handong.csee.plt.ast.value;

public class DummyV implements Value {

	@Override
	public String getASTCode() {
		return "(dummyV)";
	}

}
