package edu.handong.csee.plt.exception;

public class FreeIdentifierException extends BadSyntaxException{

	public FreeIdentifierException(String err) {
		super(err);
	}

}
