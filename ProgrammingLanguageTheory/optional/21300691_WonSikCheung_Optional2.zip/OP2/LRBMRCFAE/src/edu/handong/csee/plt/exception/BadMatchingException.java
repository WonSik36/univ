package edu.handong.csee.plt.exception;

public class BadMatchingException extends BadSyntaxException {
	
	public BadMatchingException(String err) {
		super(err);
	}
}
