package edu.handong.csee.plt.dfs;

public class MtSub extends DefrdSub {
	@Override
	public String getDSCode() {
		return "(mtSub)";
	}
}
