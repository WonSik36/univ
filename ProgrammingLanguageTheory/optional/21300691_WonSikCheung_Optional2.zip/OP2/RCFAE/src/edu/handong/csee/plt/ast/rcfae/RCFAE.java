package edu.handong.csee.plt.ast.rcfae;

import edu.handong.csee.plt.ast.AST;

public interface RCFAE extends AST {

}
