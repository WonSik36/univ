#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <windows.h>
#include <conio.h>

// screen size
#define COLUMN 80
#define ROW 24

void clrscr(void);			// clear the screen
void gotoxy(int x, int y);	// move cursor to (x, y)

void DrawCross(char array[][COLUMN]);
void DrawVertical(char array[][COLUMN]);
void DrawRandom(char array[][COLUMN]);	// optional

void FillRandom();			// provided
char GetRandomChar();		// provided

int main()
{
	char text[ROW][COLUMN];
	int x = 0, y = 0;
	
	srand(time(NULL));		// initialize random seed.
	
	// TO DO: Fill text with space characters (' ')

	DrawCross(text);

	FillRandom(text);
	getchar();
	DrawVertical(text);
	
//	The followings are just optional
//	gotoxy(1, 24);
//	system("PAUSE");
//	FillRandom(text);
//	DrawRandom(text);

	gotoxy(1, 24);
	system("PAUSE");
	
	return 0;	
}

void DrawCross(char array[][COLUMN])
{
	/*
		TO DO: complete DrawCross() to draw a cross on the 2D array.
	*/
}

void DrawVertical(char array[][COLUMN])
{
	/*
		TO DO: complete this function
	*/
}

void DrawRandom(char array[][COLUMN])
{
	/*
		Advanced problem - get 30 % bonus point
		
		Build a function that displays the contents of text in a random order.
		Use srand(), rand() and time()
		If a coordinate is duplicated with the previous random location,
			move to the next location.
			(the right column or the first column of the next row).
	*/
}

void FillRandom()
{
	int x = 0, y = 0;
	
	gotoxy(1, 1);
	for(y = 0; y < ROW; y++)
		for(x = 0; x < COLUMN; x++)
			putchar(GetRandomChar());
}

char GetRandomChar()
{
	const int noUpperCase = 26;
	const int noLowerCase = 26;
	const int noDigits = 10;

	int x = rand() % (noUpperCase + noLowerCase + noDigits);
	if(x < noUpperCase)
		return 'A' + x;
	else if(x < noUpperCase + noLowerCase)
		return 'a' + x - noUpperCase;
	else
		return '0' + x - (noUpperCase + noLowerCase);
}

void clrscr(void)			// clear the screen
{
	COORD Cur = {0, 0};
	unsigned long dwLen = 0;

	FillConsoleOutputCharacter(GetStdHandle(STD_OUTPUT_HANDLE), ' ', 80*25, Cur, &dwLen);
}

void gotoxy(int x, int y)	// move cursor to (x, y)
{
	COORD Pos = {x - 1, y - 1};

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}

