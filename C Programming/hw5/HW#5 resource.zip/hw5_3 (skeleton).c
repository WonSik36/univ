#include <stdio.h>
#include <windows.h>
#include <conio.h>


void clrscr(void);			// clear the screen
void gotoxy(int x, int y);	// move cursor to (x, y)


#define ScreenWidth 80
#define ScreenHeight 24

// Relative coordinate with respect to the center position
int Block_x[4][4] = {			// x coordinates
		{ -1, 0, 0, 1},			// dir 0
		{ -1, 0, 0, 0},			// dir 1
		{ -1, 0, 0, 1},			// dir 2
		{ 0, 0, 0, 1}			// dir 3
	};

int Block_y[4][4] = {			// y coordinates
		{ 0, 0, -1, 0},			// dir 0
		{ 0, 0, 1, -1},			// dir 1
		{ 0, 0, 1, 0},			// dir 2
		{ -1, 0, 1, 0}			// dir 3
	};

void DrawBoundary();

void DrawBlock(int x, int y, int dir, char c);

int main()
{
	int x = ScreenWidth / 2, y = ScreenHeight / 2;
	int dir = 0;

	int oldx = -1, oldy = -1;
	int oldDir = -1;

	char key = 0;

	DrawBoundary();
	DrawBlock(x, y, dir, 'O');

	while(key != 27){			// ESC
 		// save old coordinates and direction
 		
 		// read a key using getch()
 		
 		// update x, y, and dir according to the key
 		
		DrawBlock(oldx, oldy, oldDir, ' ');		// erase previous shape
		DrawBlock(x, y, dir, 'O');						// draw the shape using new coordinates and direction
	}

	return 0;
}

void DrawBoundary()
{
 		// Write your code here
}

void DrawBlock(int x, int y, int dir, char c)
// Draw the shape of a direction at (x, y)
// c is the symbol to draw
// 		If c == 'O', draw the shape.
//		If c == ' ', erase the shape.
{
 		// Write your code here
}

void clrscr(void)			// clear the screen
{
	COORD Cur = {0, 0};
	unsigned long dwLen = 0;

	FillConsoleOutputCharacter(GetStdHandle(STD_OUTPUT_HANDLE), ' ', 80*25, Cur, &dwLen);
}

void gotoxy(int x, int y)	// move cursor to (x, y)
{
	COORD Pos = {x - 1, y - 1};

	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
