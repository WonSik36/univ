#include <stdio.h>
#include <stdlib.h>

#include "graph.h"
#include "graphQS.h"

void testGraph1() {
	// create the graph 
	//  [0] -------[1]
	//   |        / |  \
			//   |      /   |  [2]
	//   |    /     |   /
	//   |  /       |  /
	//  [4]--------[3]
	//
	int V = 5;
	pGraph g = newGraph(V);
	addEdge(g, 0, 1);
	addEdge(g, 0, 4);
	addEdge(g, 1, 2);
	addEdge(g, 1, 3);
	addEdge(g, 1, 4);
	addEdge(g, 2, 3);
	addEdge(g, 3, 4);

	// print the adjacency list rep of the graph above.
	printGraph(g); printf("\n");

	depthFirstSearch(g, 0);		// output should be 
	breadthFirstSearch(g, 0);	// output should be 

	freeGraph(g);
}

void testGraph2() {
	// create the graph (PPT Example)
	//  [0] ----------------[6]
	//   | \\-----------[2]  |
	//   |  \--------[1]     |
	//   |                  /
	//   |    [3]       ---/     
	//   |   /   \     /
	//   |  /     \   /
	//  [5]--------[4]
	//
	int V = 7;
	pGraph g = newGraph(V);
	addEdge(g, 0, 5);
	addEdge(g, 4, 3);
	addEdge(g, 0, 1);
	addEdge(g, 6, 4);
	addEdge(g, 5, 4);
	addEdge(g, 0, 2);
	addEdge(g, 0, 6);
	addEdge(g, 5, 3);

	depthFirstSearch(g, 0);		// output should be 0 6 4 5 3 2 1
	printGraph(g); printf("\n");

	breadthFirstSearch(g, 0);	// output should be 0 6 2 1 5 4 3
	freeGraph(g);
}

void testGraph3() {
	// create the graph (PPT Example)
	//  [0] ----------------[6]          [7]--------[8]
	//   | \\-----------[2]  |
	//   |  \--------[1]     |           [9]--------[10]
	//   |                  /             | \
			//   |    [3]       ---/              |   \
			//   |   /   \     /                  |     \
			//   |  /     \   /                  [11]----[12]
	//  [5]--------[4]
	//
	int V = 13;
	pGraph g = newGraph(V);
	addEdge(g, 0, 5);
	addEdge(g, 4, 3);
	addEdge(g, 0, 1);
	addEdge(g, 9, 12);  //added
	addEdge(g, 6, 4);
	addEdge(g, 5, 4);
	addEdge(g, 0, 2);
	addEdge(g, 11, 12);	//added
	addEdge(g, 9, 10);	//added
	addEdge(g, 0, 6);
	addEdge(g, 7, 8);	//added
	addEdge(g, 9, 11);	//added
	addEdge(g, 5, 3);
	printGraph(g);

	connectedComponent(g);

	printf("Find a path from 0 to 3: It should be 0-6-4-5-3\n");
	pStack path = hasPathTo(g, 0, 3);

	while (sizeStack(path) > 0)
		printf("[%d] ", pop(path));
	printf("\n");

	freeStack(path);
	freeGraph(g);
}

pGraph buildTestGraph() {
	//
	//           [0]
	//          /   \
			//         /     \
			//      [1]      [2]
	//      /  \     /  \
			//     /    \   /    \
			//    [3]  [4] [5]  [6]
	//       \  |   |   /
	//        \ |   |  /
	//           [7]
	//

	pGraph g = newGraph(8);
	addEdgeFromTo(g, 0, 2);
	addEdgeFromTo(g, 0, 1);		// [0] 1->2

	addEdgeFromTo(g, 1, 4);		// [1] 3->4->0
	addEdgeFromTo(g, 1, 3);
	addEdgeFromTo(g, 1, 0);

	addEdgeFromTo(g, 2, 6);		// [2] 0->5->6
	addEdgeFromTo(g, 2, 5);
	addEdgeFromTo(g, 2, 0);

	addEdgeFromTo(g, 3, 7);		// [3] 1->7
	addEdgeFromTo(g, 3, 1);

	addEdgeFromTo(g, 4, 7);
	addEdgeFromTo(g, 4, 1);

	addEdgeFromTo(g, 5, 7);
	addEdgeFromTo(g, 5, 2);

	addEdgeFromTo(g, 6, 7);
	addEdgeFromTo(g, 6, 2);

	addEdgeFromTo(g, 7, 6);
	addEdgeFromTo(g, 7, 5);
	addEdgeFromTo(g, 7, 4);
	addEdgeFromTo(g, 7, 3);
	return g;
}

// This program test textbook Figure 6.16 & Depth first search
void testFigure6_16() {
	pGraph g = buildTestGraph();
	printGraph(g); printf("\n");
	depthFirstSearch(g, 0);		// output should be 0 1 3 7 4 5 2 6
	breadthFirstSearch(g, 0);	// output should be 0 1 2 3 4 5 6 7
	freeGraph(g);
}

// Driver program to test Graph functions
void main() {
	testGraph1();		// test a simple 5 node graph
	testGraph2();
	testFigure6_16();	// textbook Figure 6.16 & Depth first search

	testGraph3();

	printf("end of graph\n");
}
