// PQc_h
#ifndef PQc_h
#define PQc_h
#define PQKeyTypeDefined
typedef char Key;					// added for flexibility
#endif
