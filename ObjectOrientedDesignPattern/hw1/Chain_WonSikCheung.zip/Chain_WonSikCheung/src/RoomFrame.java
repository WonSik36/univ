package oodp_hw1;

public interface RoomFrame {
	public boolean isBedTypeMatch(ClientRequest request);
}
