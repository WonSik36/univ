package oodp_hw1;

public class ClientRequest {
	private String bedType;
	
	public ClientRequest(String bedType) {
		this.bedType = bedType;
	}
	
	public String getBedType() {
		return this.bedType;
	}
}
