public interface Request {
    public void accept(Visitor visitor);
}